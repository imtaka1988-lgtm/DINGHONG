package com.dinghong.controller.wechat;

import com.dinghong.service.MatchDbService;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@RestController
public class WechatController {

    private static final String TOKEN = "dinghong2026";

    private final MatchDbService matchService;

    public WechatController(MatchDbService matchService) {
        this.matchService = matchService;
    }

    @GetMapping("/wechat/callback")
    public String verify(String signature, String timestamp, String nonce, String echostr) {
        if (signature == null || timestamp == null || nonce == null || echostr == null) {
            return "wechat callback ok";
        }

        String[] arr = {TOKEN, timestamp, nonce};
        Arrays.sort(arr);
        String raw = String.join("", arr);
        String sha1 = sha1(raw);

        return sha1.equals(signature) ? echostr : "error";
    }

    @PostMapping(value = "/wechat/callback", produces = "application/xml;charset=UTF-8")
    public String receive(@RequestBody String xml) {
        System.out.println("[WECHAT_CALLBACK_XML] " + xml);

        String fromUser = getValue(xml, "FromUserName");
        String toUser = getValue(xml, "ToUserName");
        String msgType = getValue(xml, "MsgType");
        String content = getValue(xml, "Content");

        System.out.println("[WECHAT_CALLBACK_PARSED] from=" + fromUser + ", to=" + toUser + ", msgType=" + msgType + ", content=" + content);

        if ("event".equalsIgnoreCase(msgType)) {
            String event = getValue(xml, "Event");
            String eventKey = getValue(xml, "EventKey");

            System.out.println("[WECHAT_EVENT] event=" + event + ", eventKey=" + eventKey);

            if ("subscribe".equalsIgnoreCase(event)) {
                return textXml(fromUser, toUser,
                        "欢迎关注顶红体育。\n\n"
                        + "看直播：点击【看直播】→【最近直播】，或直接回复“最近直播”。\n"
                        + "查赛事：回复球队名、联赛名，例如：阿森纳、巴黎、湖人。\n"
                        + "看内容：点击【看内容】查看今日推荐和昨日复盘。\n\n"
                        + "如直播页加载较慢，请进入页面后点击“刷新直播”。");
            }

            if ("CLICK".equalsIgnoreCase(event)) {
                content = eventKeyToContent(eventKey);
                System.out.println("[WECHAT_CLICK_TO_CONTENT] " + content);
            }
        }

        if (content == null || content.trim().isEmpty()) {
            content = "智能客服";
        }



        // 内容菜单唯一入口：今日推荐 / 昨日复盘 / 最新文章
        // 今日推荐：只展示今天发布/生成的赛前文章；没有就明确提示，不拿昨天兜底。
        // 昨日复盘：展示今天创作的复盘文章，用于复盘昨天预测；不是取昨天发布的复盘。
        // 最新文章：按真实发布时间倒序取最新 3 篇。
        if ("今日推荐".equals(content) || "昨日复盘".equals(content) || "最新文章".equals(content)) {
            java.util.List<java.util.Map<String, String>> articleNews = matchService.articleNewsItemsByMenu(content, 3);
            if (articleNews != null && !articleNews.isEmpty()) {
                return newsXml(fromUser, toUser, articleNews);
            }
            return textXml(fromUser, toUser, matchService.articleMenuEmptyText(content));
        }

        // 关键词 / 直播编号优先返回二维码海报，不再弹比赛图文名片
        String mediaId = matchService.getImageMediaId(content);

        if (mediaId != null && !mediaId.trim().isEmpty()) {
            System.out.println("[WECHAT_REPLY_IMAGE] mediaId=" + mediaId);
            return imageXml(fromUser, toUser, mediaId);
        }

        String reply = matchService.reply(content);
        System.out.println("[WECHAT_REPLY_TEXT] " + reply);

        return textXml(fromUser, toUser, reply);
    }

    private String eventKeyToContent(String key) {
        if ("RECENT_LIVE".equals(key)) return "最近直播";
        if ("TODAY_FOOTBALL".equals(key)) return "今日足球";
        if ("TODAY_BASKETBALL".equals(key)) return "今日篮球";
        if ("SEARCH_MATCH".equals(key)) return "查找比赛";
        if ("LIVE_HELP".equals(key)) return "直播说明";

        if ("TODAY_PREVIEW".equals(key)) return "今日推荐";
        if ("YESTERDAY_REVIEW".equals(key)) return "昨日复盘";
        if ("LATEST_ARTICLE".equals(key)) return "最新文章";
        if ("EDITOR_ROOM".equals(key)) return "编辑部";

        if ("AI_SERVICE".equals(key)) return "智能客服";
        if ("HELP".equals(key)) return "使用说明";
        if ("CONTACT".equals(key)) return "联系人工";

        return key == null ? "" : key;
    }


    private String newsXml(String to, String from, java.util.List<java.util.Map<String, String>> items) {
        int count = Math.min(items == null ? 0 : items.size(), 8);

        StringBuilder sb = new StringBuilder();
        sb.append("<xml>")
                .append("<ToUserName><![CDATA[").append(to).append("]]></ToUserName>")
                .append("<FromUserName><![CDATA[").append(from).append("]]></FromUserName>")
                .append("<CreateTime>").append(System.currentTimeMillis() / 1000).append("</CreateTime>")
                .append("<MsgType><![CDATA[news]]></MsgType>")
                .append("<ArticleCount>").append(count).append("</ArticleCount>")
                .append("<Articles>");

        for (int i = 0; i < count; i++) {
            java.util.Map<String, String> item = items.get(i);

            sb.append("<item>")
                    .append("<Title><![CDATA[").append(safe(item.get("title"))).append("]]></Title>")
                    .append("<Description><![CDATA[").append(safe(item.get("description"))).append("]]></Description>")
                    .append("<PicUrl><![CDATA[").append(safe(item.get("picUrl"))).append("]]></PicUrl>")
                    .append("<Url><![CDATA[").append(safe(item.get("url"))).append("]]></Url>")
                    .append("</item>");
        }

        sb.append("</Articles>")
                .append("</xml>");

        return sb.toString();
    }


    private String textXml(String to, String from, String content) {
        return "<xml>"
                + "<ToUserName><![CDATA[" + to + "]]></ToUserName>"
                + "<FromUserName><![CDATA[" + from + "]]></FromUserName>"
                + "<CreateTime>" + (System.currentTimeMillis() / 1000) + "</CreateTime>"
                + "<MsgType><![CDATA[text]]></MsgType>"
                + "<Content><![CDATA[" + safe(content) + "]]></Content>"
                + "</xml>";
    }

    private String imageXml(String to, String from, String mediaId) {
        return "<xml>"
                + "<ToUserName><![CDATA[" + to + "]]></ToUserName>"
                + "<FromUserName><![CDATA[" + from + "]]></FromUserName>"
                + "<CreateTime>" + (System.currentTimeMillis() / 1000) + "</CreateTime>"
                + "<MsgType><![CDATA[image]]></MsgType>"
                + "<Image><MediaId><![CDATA[" + mediaId + "]]></MediaId></Image>"
                + "</xml>";
    }

    private String safe(String s) {
        return s == null ? "" : s;
    }

    private String getValue(String xml, String tag) {
        if (xml == null || tag == null) return "";

        Pattern cdataPattern = Pattern.compile("<" + tag + ">\\s*<!\\[CDATA\\[(.*?)]]>\\s*</" + tag + ">", Pattern.DOTALL);
        Matcher cdataMatcher = cdataPattern.matcher(xml);
        if (cdataMatcher.find()) {
            return cdataMatcher.group(1).trim();
        }

        Pattern normalPattern = Pattern.compile("<" + tag + ">(.*?)</" + tag + ">", Pattern.DOTALL);
        Matcher normalMatcher = normalPattern.matcher(xml);
        if (normalMatcher.find()) {
            return normalMatcher.group(1).trim();
        }

        return "";
    }

    private String sha1(String str) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] bytes = md.digest(str.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();

            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }

            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }
}
